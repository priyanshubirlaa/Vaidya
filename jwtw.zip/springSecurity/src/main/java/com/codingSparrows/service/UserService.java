package com.codingSparrows.service;


import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


import com.codingSparrows.model.User;
import com.codingSparrows.repo.UserInfoRepository;

import java.util.List;
import java.util.Optional;


@Service
public class UserService {

	
   

    @Autowired
    private UserInfoRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

   

    public List<User> getProducts() {
        return repository.findAll();
    }

    public User getProduct(int id) {
          Optional<User> optionalUser = repository.findById(id);
        return optionalUser.orElse(null);
    }


    public String addUser(User userInfo) {
        userInfo.setPassword(passwordEncoder.encode(userInfo.getPassword()));
        repository.save(userInfo);
        return "user added to system ";
    }
}

